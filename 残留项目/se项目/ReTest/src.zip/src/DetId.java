import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class DetId {
	public static void main(String[] args) {
		String pathName="D://test.txt";
		try {
			FileReader reader = new FileReader(pathName);
			BufferedReader br = new BufferedReader(reader);
			String tempStr="";
			while((tempStr=br.readLine())!=null) {
				detect(tempStr);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}
	
	public static void detect(String s) {
		String regex1 = "^[A-Za-z][A-Za-z1-9_-]*+";
		String regex2="for(.*:.*:.*)";
		Pattern pattern1 = Pattern.compile(regex1); 
		Pattern pattern2 = Pattern.compile(regex2); 
		String[] ss=s.split("[ \\+\\-\\*\\/\\=]");
		for(int i=0;i<ss.length;i++) {
			Matcher matcher=pattern2.matcher(ss[i]);
			if(matcher.find()){  
		        System.out.println("<"+matcher.group()+">"+" is a for loop");  
		        continue;
			}
			matcher = pattern1.matcher(ss[i]);  
			if(matcher.find()){  
			        System.out.println("<"+matcher.group()+">"+" is variable");   
			}
		}
	}
}
