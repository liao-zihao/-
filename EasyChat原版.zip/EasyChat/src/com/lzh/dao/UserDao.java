package com.lzh.dao;

import com.lzh.pojo.User;

public interface UserDao {
	public User login(User user);
}
